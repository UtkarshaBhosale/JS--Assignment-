console.log("Heyyyy");
 let marks = prompt("Ente your marks:");
 if (marks >= 60 )
 {
     console.log("Marks are greater than 60 and grade is A.");
 
 }
 else if (marks >=50 )
 {
    console.log("Marks are 50 and grade is B.");
 }
 else
 {
    console.log("Fail");
 
 }