console.log("Hello");

function Even()
{
    let num = prompt("Enter the number:");

        if (num %2 == 0)
        {
            console.log(`The number entered is ${num} and Number is even`);
        }
        else
        {
            console.log(`The number entered is ${num} and Number is odd`);

        }
    
}
Even();
    
   



