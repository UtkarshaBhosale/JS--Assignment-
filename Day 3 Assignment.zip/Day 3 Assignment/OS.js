console.log("Hiiiiii");
 

var OSName=["Android" , "9"]




console.log(`The OS name is ${OSName[0]} and version is ${OSName[1]}.`);


   
 
    

