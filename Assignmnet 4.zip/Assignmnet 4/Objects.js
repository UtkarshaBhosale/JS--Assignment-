console.log("Destructuring Objects");

const student = {
    name: "Helsinki",
    age: 24,
    projects: {
        diceGame: "Two player dice game using JavaScript"
    }
};

const{name,age}=student;
console.log(name,age);
console.log(student.projects.diceGame);


