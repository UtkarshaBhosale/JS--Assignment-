console.log("Number greater than 100");

let num;
do{
    num = prompt("Enter a number greater than 100", 0);
} while (num <=100 && num);
console.log(`Number entered is ${num} `);