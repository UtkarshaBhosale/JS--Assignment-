console.log("Grocery Shopping");

var shoppingLIst = ["Bread", "milk", "butter", "tomato sauce"];
console.log(shoppingLIst);

var shoppingBasket = shoppingLIst;
shoppingBasket.push("apple", "banana");
console.log(shoppingBasket);