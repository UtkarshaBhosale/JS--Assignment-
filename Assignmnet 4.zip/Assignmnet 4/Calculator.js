console.log("Question 4 ...................");

console.log("Calculataor");
console.log("1. Addtion");
console.log("2. Subtraction");
console.log("3. Multiplication");
console.log("4. Division");
console.log("5. Square root");
console.log("6. Percentage");
let calculator = prompt("Select operation",0);

if (calculator == 1) {
    let x = prompt(" Enter 1st number",0);
    let y = prompt(" Enter 2nd number",0);        
    z = +x + +y; 
    console.log(`Addition of ${x} and ${y} is ${z}`);  
}
else if (calculator == 2) {
    let x = prompt(" Enter 1st number",0);
    let y = prompt(" Enter 2nd number",0);        
    z = +x - +y; 
    console.log(`Substraction of ${x} and ${y} is ${z}`);  
}
else if (calculator == 3) {
    let x = prompt(" Enter 1st number",0);
    let y = prompt(" Enter 2nd number",0);        
    z = +x * +y; 
    console.log(`Multiplication of ${x} and ${y} is ${z}`);  
}
else if (calculator == 4) {
    let x = prompt(" Enter 1st number",0);
    let y = prompt(" Enter 2nd number",0);        
    z = +x / +y; 
    console.log(`Division of ${x} and ${y} is ${z}`);  
}
else if (calculator == 5) {
    let x = prompt(" Enter number",0);
    z = Math.sqrt(x); 
    console.log(`Square root of ${x} is ${z}`);  
}
else if (calculator == 6) {
    let x = prompt(" Enter obtained value",0);      
    let y = prompt(" Enter total value",0);  
    z = (x * 100)/ y; 
    console.log(`Percentage of ${x} from ${y} is ${z}`);  
}
else{
    console.log("Invalid selection");
}